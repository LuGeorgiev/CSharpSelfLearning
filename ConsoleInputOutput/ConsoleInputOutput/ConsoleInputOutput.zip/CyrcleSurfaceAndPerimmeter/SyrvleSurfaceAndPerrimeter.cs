﻿using System;


namespace CyrcleSurfaceAndPerimmeter
{
    class SyrvleSurfaceAndPerrimeter
    {
        static void Main()
        {
            Console.WriteLine("Plese, enter teh radius of the cyrcle");
            float r = float.Parse(Console.ReadLine());

            Console.WriteLine("The surface of the cyrcle is: {0:N2} \nThe Perrimeter of the cyrcle is; {1:N2}", Math.PI*r*r, Math.PI*2*r);
        }
    }
}
