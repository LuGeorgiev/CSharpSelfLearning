﻿using System;
using System.Collections.Generic;
using System.Text;


    class Parent
    {
        public string FullName { get; set; }
        public string Birthday { get; set; }

        public Parent()
        {

        }
    }

