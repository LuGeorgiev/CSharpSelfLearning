﻿using System;
using System.Collections.Generic;
using System.Text;


    class Child
    {
        public string FullName { get; set; }
        public string Birthday { get; set; }
    }

